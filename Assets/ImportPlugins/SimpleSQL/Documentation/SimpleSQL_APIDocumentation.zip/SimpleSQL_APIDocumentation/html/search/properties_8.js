var searchData=
[
  ['result_301',['Result',['../class_simple_s_q_l_1_1_s_q_lite_exception.html#a2f1e262a97cd4d5c68967f7685e0e549',1,'SimpleSQL::SQLiteException']]]
];
