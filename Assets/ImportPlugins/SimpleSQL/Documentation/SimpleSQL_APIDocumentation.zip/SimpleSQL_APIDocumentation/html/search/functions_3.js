var searchData=
[
  ['databasecreateddelegate_199',['DatabaseCreatedDelegate',['../namespace_simple_s_q_l.html#ad94e6be11ea46633787955f3153a628e',1,'SimpleSQL']]],
  ['defaultattribute_200',['DefaultAttribute',['../class_simple_s_q_l_1_1_default_attribute.html#ac089279314be275788883e28ddf46b6d',1,'SimpleSQL::DefaultAttribute']]],
  ['delete_3c_20t_20_3e_201',['Delete&lt; T &gt;',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a58b8e4d7dacbfff312e18ad66bf60128',1,'SimpleSQL.SimpleSQLManager.Delete&lt; T &gt;()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a97afb017425454832ea3ce516e199293',1,'SimpleSQL.SQLiteConnection.Delete&lt; T &gt;()']]],
  ['dispose_202',['Dispose',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a8f4022684f628c7bb0cf742655106581',1,'SimpleSQL.SimpleSQLManager.Dispose()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a68924932795990414d7a466f5ed12b78',1,'SimpleSQL.SQLiteConnection.Dispose()'],['../class_simple_s_q_l_1_1_prepared_sql_lite_insert_command.html#a35aaa631bda884827af371edb3718ea9',1,'SimpleSQL.PreparedSqlLiteInsertCommand.Dispose()']]]
];
