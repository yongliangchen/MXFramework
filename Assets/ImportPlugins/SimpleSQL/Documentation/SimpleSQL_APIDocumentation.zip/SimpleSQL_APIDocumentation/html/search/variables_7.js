var searchData=
[
  ['workingname_273',['workingName',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#ad869abcdb7491aea4f926027dc298abc',1,'SimpleSQL::SimpleSQLManager']]]
];
