var searchData=
[
  ['orderby_3c_20u_20_3e_225',['OrderBy&lt; U &gt;',['../class_simple_s_q_l_1_1_table_query.html#a8d7e79149d6b1e1de3159128ebeedf29',1,'SimpleSQL::TableQuery']]],
  ['orderbydescending_3c_20u_20_3e_226',['OrderByDescending&lt; U &gt;',['../class_simple_s_q_l_1_1_table_query.html#ada9a6167bc696f0925743e31ac9a33f5',1,'SimpleSQL::TableQuery']]]
];
