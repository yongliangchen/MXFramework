var searchData=
[
  ['changeworkingname_262',['changeWorkingName',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#aa119274ed9f24644e6db2546715daa50',1,'SimpleSQL::SimpleSQLManager']]],
  ['columns_263',['columns',['../class_simple_s_q_l_1_1_simple_data_table.html#a04a5b68f1e89785240807c84e185cd4b',1,'SimpleSQL::SimpleDataTable']]]
];
