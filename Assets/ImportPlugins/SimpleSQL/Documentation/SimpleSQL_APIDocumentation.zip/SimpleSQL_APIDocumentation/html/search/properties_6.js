var searchData=
[
  ['name_299',['Name',['../class_simple_s_q_l_1_1_table_mapping_1_1_column.html#a371e2e644ff6ed161c7189ae1321ab03',1,'SimpleSQL.TableMapping.Column.Name()'],['../class_simple_s_q_l_1_1_s_q_lite_command_1_1_binding.html#a631260adb4d0a993391d60d0c0c523d0',1,'SimpleSQL.SQLiteCommand.Binding.Name()']]]
];
