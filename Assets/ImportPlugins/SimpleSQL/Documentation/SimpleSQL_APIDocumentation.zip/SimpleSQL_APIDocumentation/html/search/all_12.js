var searchData=
[
  ['uniqueattribute_142',['UniqueAttribute',['../class_simple_s_q_l_1_1_unique_attribute.html',1,'SimpleSQL']]],
  ['update_143',['Update',['../class_simple_s_q_l_1_1_s_q_lite_connection.html#a7e9e38ad877a241931d12f48e3bc7763',1,'SimpleSQL.SQLiteConnection.Update(object obj)'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ad530e416b2b1c9a3aeb9f362e51cf4a9',1,'SimpleSQL.SQLiteConnection.Update(object obj, Type objType)']]],
  ['updatetable_144',['UpdateTable',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#ab9502aca68f70b82b718b262fbb959d5',1,'SimpleSQL.SimpleSQLManager.UpdateTable(object obj)'],['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a426356200ad106b4cd8523ad37c87c20',1,'SimpleSQL.SimpleSQLManager.UpdateTable(object obj, Type objType)']]]
];
