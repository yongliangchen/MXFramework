var searchData=
[
  ['handle_64',['Handle',['../class_simple_s_q_l_1_1_s_q_lite_connection.html#aa6bef018bc4273040caa654d47f6f9e2',1,'SimpleSQL::SQLiteConnection']]],
  ['hasautoincpk_65',['HasAutoIncPK',['../class_simple_s_q_l_1_1_table_mapping.html#aa79f62c8dc0b5d0ae5c583c3e795c041',1,'SimpleSQL::TableMapping']]]
];
