var searchData=
[
  ['busytimeout_277',['BusyTimeout',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a1dd77412c246fcdd11c364e08f88ba97',1,'SimpleSQL.SimpleSQLManager.BusyTimeout()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#ade7ad90424209fd71b7edaccc1734100',1,'SimpleSQL.SQLiteConnection.BusyTimeout()']]]
];
