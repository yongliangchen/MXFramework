var searchData=
[
  ['tablemapping_172',['TableMapping',['../class_simple_s_q_l_1_1_table_mapping.html',1,'SimpleSQL']]],
  ['tablequery_173',['TableQuery',['../class_simple_s_q_l_1_1_table_query.html',1,'SimpleSQL']]]
];
