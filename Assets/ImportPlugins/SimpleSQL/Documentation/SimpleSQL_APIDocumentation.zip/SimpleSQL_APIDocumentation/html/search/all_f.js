var searchData=
[
  ['relativetopersistentdata_104',['RelativeToPersistentData',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#afd52b8e62f594578a86cbb5cdc06e3c1ae494d0d41144f152d410e8ae30bfbdc6',1,'SimpleSQL::SimpleSQLManager']]],
  ['result_105',['Result',['../class_simple_s_q_l_1_1_s_q_lite_exception.html#a2f1e262a97cd4d5c68967f7685e0e549',1,'SimpleSQL::SQLiteException']]],
  ['rollback_106',['Rollback',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a9d78c68abb2fc09c5f1520eab2016c0a',1,'SimpleSQL.SimpleSQLManager.Rollback()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#afd530662b812414fc27c50adfa99a366',1,'SimpleSQL.SQLiteConnection.Rollback()']]],
  ['rows_107',['rows',['../class_simple_s_q_l_1_1_simple_data_table.html#a1d7f38a47557789e6e59c902a2e44e0b',1,'SimpleSQL::SimpleDataTable']]],
  ['runintransaction_108',['RunInTransaction',['../class_simple_s_q_l_1_1_simple_s_q_l_manager.html#a2a63de3e76a33e24d0ce829829ef7f91',1,'SimpleSQL.SimpleSQLManager.RunInTransaction()'],['../class_simple_s_q_l_1_1_s_q_lite_connection.html#aa9fc11ad3ea2787b3836bd04e2ac7387',1,'SimpleSQL.SQLiteConnection.RunInTransaction()']]],
  ['runtimehelper_2ecs_109',['RuntimeHelper.cs',['../_runtime_helper_8cs.html',1,'']]]
];
