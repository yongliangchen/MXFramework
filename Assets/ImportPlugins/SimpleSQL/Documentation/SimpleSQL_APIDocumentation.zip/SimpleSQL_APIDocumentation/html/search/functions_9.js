var searchData=
[
  ['new_223',['New',['../class_simple_s_q_l_1_1_s_q_lite_exception.html#a977bdf4df068cdffe440037e2f7863ee',1,'SimpleSQL::SQLiteException']]],
  ['newrow_224',['NewRow',['../class_simple_s_q_l_1_1_simple_data_table.html#a5d179dc530d6bebf21cd37296d0f50a8',1,'SimpleSQL::SimpleDataTable']]]
];
